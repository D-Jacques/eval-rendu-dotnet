﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity.Migrations;

// TP DotNet, la guilde des Héros : DUCROUX Jacques, NGUYEN Viviane

namespace WindowsFormsAppEval
{
    public partial class Form1 : Form
    {
        //Entitée reliée à notre base de données
        GuildeEntities guilde;

        //Variable globale dans notre classe Form1
        personnage personnage = null;

        objet objet_personnage = null;

        public Form1()
        {
            guilde = new GuildeEntities();
            InitializeComponent();
            refreshTable();
        }

        private void getPersonnage(int id)
        {
            // l'Id correspond au personnage selectionné dans le DataGrid, on fait une requete en bdd pour le récupérer
            personnage = guilde.personnage.SingleOrDefault(perso => perso.id_personnage == id);
            loadPersonnageInForm();
        }

        // Une fois que les données du personnage sont récupérés on les charges dans le formulaire
        private void loadPersonnageInForm()
        {
            textBoxNom.Text = personnage.nom;
            textBoxPrenom.Text = personnage.prenom;
            textBoxSpecialite.Text = personnage.specialite;
            textBoxClasse.Text = personnage.classe;
            numericUpDownLevel.Value = personnage.niveau;
            numericUpDownPuissance.Value = personnage.puissance;
            numericUpDownMission.Value = personnage.mission;
            textBoxReputation.Text = personnage.reputation;
        }

        /*
         * Fonction de création ou de mise à jour de personnage
         * isCreate est un boolean qui détermine si l'on veut créer ou modifier un personnage
         * Par défaut, on fait une modification
         */
        private void updateOrCreateCurrentPersonnage(Boolean isCreate = false)
        {
            int id;
            // Lors de la validation de notre fomulaire, on créer un nouvel objet personnage
            // Si notre personnage à déjà un id, on met dans id_personnage son id en bdd
            // Sinon il n'a pas d'ID, il faut le créer.

            if (isCreate)
            {
                id = 0;
            } else
            {
                id = personnage.id_personnage;
            }

            personnage = new personnage()
           {
                id_personnage = id,
                nom = textBoxNom.Text,
                prenom = textBoxPrenom.Text,
                specialite = textBoxSpecialite.Text,
                classe = textBoxClasse.Text,
                niveau = (int)numericUpDownLevel.Value,
                puissance = (int)numericUpDownPuissance.Value,
                mission = (int)numericUpDownMission.Value,
                reputation = textBoxReputation.Text
           };
            // Si on créer un personnage, on créer sa sacoche qui comporte l'id du personnage (Sacoche liée au personnage).
            if (isCreate)
            {
                guilde.sacoche.Add(new sacoche()
                {
                    id_personnage = personnage.id_personnage
                });
            }
            // On persiste le nouveau personnage OU les modifications du personnage actuel en bdd
            // On sauvegarde la création ou la modification en base de donnée
            guilde.personnage.AddOrUpdate(personnage);
            guilde.SaveChanges();
        }

        //On fait la même chose que pour le personnage
        private void updateOrCreateCurrentObject(Boolean isCreate = false)
        {

            int id_obj;

            if (isCreate)
            {
                id_obj = 0;
            } else
            {
                id_obj = objet_personnage.id;
            }

            objet_personnage = new objet()
            {
                id = id_obj,
                nom = textBoxObjectName.Text,
                niveau = int.Parse(numericUpDownObjectLevel.Value.ToString()),
                quantite = int.Parse(numericUpDownObjectQuantite.Value.ToString()),
                prix = int.Parse(numericUpDownObjectPrix.Value.ToString()),
                description = textBoxObjectDesc.Text,
                id_sacoche = personnage.sacoche.id_personnage
            };
            guilde.objet.AddOrUpdate(objet_personnage);
            guilde.SaveChanges();
        }

        /*
         * Fonction qui permet de remplir automatiquement les champs lorsque l'on sélectionne un objet 
         */ 
        private void loadObjectInForm()
        {
            if (objet_personnage == null)
                return;

            textBoxObjectName.Text = objet_personnage.nom;
            numericUpDownObjectLevel.Value = (int)objet_personnage.niveau;
            numericUpDownObjectQuantite.Value = (int)objet_personnage.quantite;
            numericUpDownObjectPrix.Value = (int)objet_personnage.prix;
            textBoxObjectDesc.Text = objet_personnage.description;
        }

        /*
         * Lorsque l'on sélectionne un objet, on passe son id a cette méthode et on va chercher l'objet sélectionné
         * Dans la base de données
         */
        private void loadObjectInForm(int id)
        {
            objet_personnage = guilde.objet.SingleOrDefault(objet => objet.id == id);
            loadObjectInForm();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            //On controle si un champ n'est pas vide !
            foreach (Control control in tableLayoutPanelPerso.Controls)
            {
                if (control.GetType() == typeof(TextBox) && string.IsNullOrWhiteSpace(control.Text))
                {
                    //Si un champ est vide, on interrompt la fonction d'ajout et on affiche un message d'erreur
                    MessageBox.Show("Un champ est vide");
                    return;
                }
            }
            updateOrCreateCurrentPersonnage(true);
            emptyPersonnageField();
            refreshTable();
        }

        //On recharge les données du datagrid lorsque l'on ajoute ou modifie
        public void refreshTable()
        {
            dataGridViewPersonnages.DataSource = null;
            guilde = new GuildeEntities();
            dataGridViewPersonnages.DataSource = guilde.personnage.ToList();
            dataGridViewPersonnages.Columns["sacoche"].Visible = false;
            dataGridViewPersonnages.Columns["id_personnage"].Visible = false;

            if (personnage != null) {
                dataGridViewSacoche.DataSource = null;
                personnage = guilde.personnage.SingleOrDefault(p => p.id_personnage == personnage.id_personnage);
                dataGridViewSacoche.DataSource = personnage.sacoche.objet.ToList();
                dataGridViewSacoche.Columns["sacoche"].Visible = false;
                dataGridViewSacoche.Columns["id_sacoche"].Visible = false;
                dataGridViewSacoche.Columns["id"].Visible = false;
            } else
            {
                dataGridViewSacoche.DataSource = null;
            }

        }

        private void buttonModifier_Click(object sender, EventArgs e)
        {
            //On controle si un champ n'est pas vide !
            foreach (Control control in tableLayoutPanelPerso.Controls)
            {
                if (control.GetType() == typeof(TextBox) && string.IsNullOrWhiteSpace(control.Text))
                {
                    //Si un champ est vide, on interrompt la fonction d'ajout et on affiche un message d'erreur
                    MessageBox.Show("Un champ est vide");
                    return;
                }
            }
            updateOrCreateCurrentPersonnage();
            refreshTable();
        }

        /*
         * Méthode lors de la selection d'un personnage dans le dataGrid du personnage
         */ 
        private void dataGridViewPersonnages_SelectionChanged(object sender, EventArgs e)
        {
            // Si on à pas de personnages selectionné on ne retourne rien (vu que l'on à pas de personnages)
            if (dataGridViewPersonnages.Rows.GetRowCount(DataGridViewElementStates.Selected) <= 0)
                return;

            var personnageData = dataGridViewPersonnages.SelectedRows[0];

            //On récupère l'id du personnage selectionné (première case du dataGridView) pour aller le chercher en base de données
            getPersonnage(int.Parse(personnageData.Cells[0].Value.ToString()));
            refreshTable();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (personnage == null) return;
            guilde.personnage.Remove(personnage);
            guilde.SaveChanges();
            emptyPersonnageField();
            personnage = null;
            refreshTable();
        }

        private void buttonAddObj_Click(object sender, EventArgs e)
        {
            foreach (Control control in tableLayoutPanelObjet.Controls)
            {
                if (control.GetType() == typeof(TextBox) && string.IsNullOrWhiteSpace(control.Text))
                {
                   MessageBox.Show("Un champ est vide");
                   return;
                }
            }
            updateOrCreateCurrentObject(true);
            emptyObjectField();
            refreshTable();
        }

        private void buttonModObj_Click(object sender, EventArgs e)
        {
            foreach (Control control in tableLayoutPanelObjet.Controls)
            {
                if (control.GetType() == typeof(TextBox) && string.IsNullOrWhiteSpace(control.Text))
                {
                    MessageBox.Show("Un champ est vide");
                    return;
                }
            }
            updateOrCreateCurrentObject();
            refreshTable();
        }

        private void buttonDelObj_Click(object sender, EventArgs e)
        {
            if (objet_personnage == null) return;
           
            guilde.objet.Remove(guilde.objet.SingleOrDefault(objet => objet.id == objet_personnage.id));
            guilde.SaveChanges();
            emptyObjectField();
            objet_personnage = null;
            refreshTable();
        }

        /*
        * Methode appelée lorsque l'on sélectionne un objet d'un héros dans le dataGridViewSacoche
        */
        private void dataGridViewSacoche_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewSacoche.Rows.GetRowCount(DataGridViewElementStates.Selected) <= 0)
                return;

            // Récupération de la ligne sélectionné contenant les données de l'objet
            var objetData = dataGridViewSacoche.SelectedRows[0];

            //On passe a cette méthode l'id de l'objet pour le récupérer en bdd
            loadObjectInForm(int.Parse(objetData.Cells[0].Value.ToString()));
            refreshTable();
        }

        private void emptyPersonnageField()
        {
            textBoxNom.Text = "";
            textBoxPrenom.Text = "";
            textBoxSpecialite.Text = "";
            textBoxClasse.Text = "";
            numericUpDownLevel.Value = 0;
            numericUpDownPuissance.Value = 0;
            numericUpDownMission.Value = 0;
            textBoxReputation.Text = "";
        }

        private void emptyObjectField()
        {
            textBoxObjectName.Text = "";
            numericUpDownObjectLevel.Value = 0;
            numericUpDownObjectQuantite.Value = 0;
            numericUpDownObjectPrix.Value = 0;
            textBoxObjectDesc.Text = "";
        }
    }
}
